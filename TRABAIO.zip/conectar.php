<?php
// Configurações do banco de dados
$host = 'localhost'; // Host do banco de dados
$username = 'root'; // Usuário do banco
$password = ''; // Senha do banco
$dbname = 'passeio'; // Nome do banco
$porta = 3307;


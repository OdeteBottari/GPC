<?php
include('../conectar.php');

// Conecta ao banco de dados
$conn = mysqli_connect($host, $username, $password, $dbname, $porta);

// Verifica a conexão
if (!$conn) {
    die("Erro ao conectar ao banco de dados: " . mysqli_connect_error());
}

// Obtém os dados enviados pelo formulário
$rating = $_POST['rating'];
    $comment = $_POST['comment'];

// Monta a query de inserção
$sql = "INSERT INTO avaliacoes_site (rating, comment) VALUES ('$rating', '$comment')";

// Executa a query
if (mysqli_query($conn, $sql)) {
    echo "Dados inseridos com sucesso!";
    echo "<h1>Avaliação Recebida!</h1>";
    echo "<p>Nota: $rating</p>";
    echo "<p>Comentário: $comment</p>";
} else {
    echo "Erro ao inserir os dados: " . mysqli_error($conn);
}

// Fecha a conexão com o banco de dados
mysqli_close($conn);

?>
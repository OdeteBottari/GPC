<?php
session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.html");
    exit();
}

include('../conectar.php');

// Conecta ao banco de dados
$conn = mysqli_connect($host, $username, $password, $dbname, $porta);


if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

$sql = "SELECT * FROM participante ORDER BY nome ASC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="admin_style.css">
    <title>Painel Administrativo</title>
</head>
<body>
    <h1>Painel Administrativo</h1>
    <table>
        <tr>
            <th>Nome Completo</th>
            <th>Categoria</th>
            <th>Subcategoria</th>
            <th>Ações</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['nome']; ?></td>
                <td><?php echo $row['email']; ?></td>
                <td>
                    <a href="view_participant.php?id=<?php echo $row['id']; ?>">Visualizar</a> |
                    <a href="delete_participant.php?id=<?php echo $row['id']; ?>">Excluir</a> |
                    <a href="edit_participant.php?id=<?php echo $row['id']; ?>">Alterar</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>

    <a href="logout.php">Sair</a>

</body>
</html>

<?php 
$conn->close();
?>

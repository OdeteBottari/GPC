<?php
session_start();

include('../conectar.php');

// Conecta ao banco de dados
$conn = mysqli_connect($host, $username, $password, $dbname, $porta);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Sanitizar entrada
function sanitizeInput($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

// Obter e sanitizar dados do formulário
$nome = sanitizeInput($_POST['nome']);
$senha_input = sanitizeInput($_POST['senha']);

// Consultar administrador no banco de dados
$sql = "SELECT * FROM administradores WHERE nome='$nome'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    
    // Verificar a senha
    if (password_verify($senha_input, $row['senha'])) {
        $_SESSION['admin_logged_in'] = true;
        header("Location: admin_dashboard.php"); // Redirecionar para o painel administrativo
        exit();
    } else {
        echo "Senha incorreta.";
    }
} else {
    echo "Administrador não encontrado.";
}

$conn->close();
?>

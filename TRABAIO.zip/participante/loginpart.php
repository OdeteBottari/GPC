<?php
session_start();

include('../conectar.php');

// Conectar ao banco de dados
$conn = new mysqli($host, $username, $password, $dbname, $porta);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Sanitizar entrada
function sanitizeInput($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

// Obter e sanitizar dados do formulário
$email = sanitizeInput($_POST['email'] ?? '');
$senha_input = sanitizeInput($_POST['senha'] ?? '');

if (empty($email) || empty($senha_input)) {
    echo "Por favor, preencha todos os campos.";
    exit();
}

// Realizar consulta direta com email e senha
$stmt = $conn->prepare("SELECT * FROM participante WHERE email = ? AND senha = ?");
$stmt->bind_param("ss", $email, $senha_input);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $_SESSION['admin_logged_in'] = true;
    header("Location: ../index.html"); // Redirecionar para o painel participante
    exit();
} else {
    echo "Email ou senha incorretos.";
}

$stmt->close();
$conn->close();
?>
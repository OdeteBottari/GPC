<?php
include('../conectar.php');

// Conecta ao banco de dados
$conn = mysqli_connect($host, $username, $password, $dbname, $porta);

// Verifica a conexão
if (!$conn) {
    die("Erro ao conectar ao banco de dados: " . mysqli_connect_error());
}

// Obtém os dados enviados pelo formulário
$email = $_POST['email'];
    $senha = $_POST['senha'];

// Monta a query de inserção
$sql = "INSERT INTO participante (email, senha) VALUES ('$email', '$senha')";

// Executa a query
if (mysqli_query($conn, $sql)) {
    header('Location: loginpart.html');
} else {
    echo "Erro ao inserir os dados: " . mysqli_error($conn);
}

// Fecha a conexão com o banco de dados
mysqli_close($conn);

?>